package com.LeiSrl.Start;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerProgramSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
