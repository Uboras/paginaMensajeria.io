package com.LeiSrl.Start;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerProgramSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerProgramSpringApplication.class, args);
	}

}
